import React from 'react';
import ReactDOM from 'react-dom/client';

import './index.css';
import './styles/header-menu.css';
//import './styles/login.css';
//import './styles/products.css';
import './styles/search.css';
import './styles/styles.css';
import './styles/toggle.css';
import './styles/product.css'

import App from './App';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);

