import React from 'react';
//import './App.css';
import './components/additionalamount';
import './components/frontend/Header';
import './components/frontend/Banner';
import Header from './components/frontend/Header';
import Banner from './components/frontend/Banner';
import AboutUs from './components/frontend/AboutUs';
import Products from './components/frontend/Products';
import Quality from './components/frontend/Quality';
import ContactSection from './components/frontend/ContactSection';
import Footer from './components/frontend/Footer';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        My thesis application
      </header>
      <Header/>
      <Banner/>
      <Products/>
      <Quality/>
      <AboutUs/>
      <ContactSection/>
      <Footer/>
      {/*<RetrieveAdditionalAmount/>
      <RetrieveAmountCalculationType/>*/}
    </div>
  );
}

export default App;
