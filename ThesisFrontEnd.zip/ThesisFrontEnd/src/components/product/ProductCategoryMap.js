
import ProductCategory from "./ProductCategory";

function ProductCategoryMap(props) {
    // console.log(props?.data);

    return (
        <>
            {props.data.map((category, index) => (
                <ProductCategory key={index} data={category}/>
            ))}
        </>
    );
}

export default ProductCategoryMap;