const productCategoryList = [
    {
        name: "Sausage",
        ImageUrl: "https://www.dubreton.com/sites/default/files/styles/full/public/2022-05/saucisse.png?h=aa2113cc&itok=HczPaRVm",
        link:"#",
        description:"Flavorful sausages made from the finest ingredients."
    },
    {
        name:"Bacon",
        imageUrl: "https://steakfutar.hu/wp-content/uploads/2020/11/Bacon-scaled.jpg",
        link: "#",
        description: "Crispy and savory bacon perfect for any meal."
    }
];

export default productCategoryList;