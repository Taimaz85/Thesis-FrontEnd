

function ProductCategory(props) {

    console.log(props.data);
    <>    <h1>Products</h1>
    <h1>Products</h1>
    <h1>Products</h1>
    <h1>Products</h1>
    <h1>Products</h1>
    </>
    return (
        <div className="product-category">
            
            <h2>{props.data.name}</h2>
            <img className="product-category-picture" src= {props.data.imageUrl}/>
        </div>
    );
}

export default ProductCategory;