import React, { useState, useEffect } from 'react';
import AddRemoveModifyButtons from './AddRemoveModifyButtons';

// function HandleADLButtons() {
//     // Tracks which form to show: 'add', 'remove', 'modify', 'edit'
//     const [showForm, setShowForm] = useState(null); 
//     const [formData, setFormData] = useState({
//         id: '',
//         name: '',
//         currencyTypeID: '',
//         value: '',
//         description: '',
//         status: ''
//     });

//     const handleInputChange = (e) => {
//         const { name, value } = e.target;
//         setFormData({ ...formData, [name]: value });
//     };

//     // Placeholder functions for buttons
//     const handleAdd = () => setShowForm('add');
//     const handleRemove = () => setShowForm('remove');
//     const handleModify = () => setShowForm('modify');
//     const handleCancel = () => {
//         setShowForm(null);
//         setFormData({
//             id: '',
//             name: '',
//             amountCalculationTypeId: '',
//             amount: '',
//             description: '',
//             status: ''
//         });
//     };

//     const submitAdd = () => {
//         fetch('/api/add_amountcalculationtype', {
//             method: 'POST',
//             headers: { 'Content-Type': 'application/json' },
//             body: JSON.stringify(formData)
//         })
//             .then((response) => response.json())
//             .then((data) => {
//                 alert(data.message);
//                 setAdditionalAmounts((prev) => [...prev, formData]);
//                 handleCancel();
//             })
//             .catch((err) => alert('Error adding entry: ' + err));
//     };


// }

function RetrieveAmountCalculationType() {
    const [amountCalculationType, setAmountCalculationType] = useState([]);
    const [error, setError] = useState(null);

    // Use useEffect to fetch data when the component mounts
    useEffect(() => {
        fetch("http://127.0.0.1:5000/amountcalculationtype")
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then((data) => setAmountCalculationType(data))
        .catch((err) => setError(err.message));
    }, []); // Empty dependency array unsures this runs only once on mount

    return (
        <div>
            <h2>Amount Calculation Types</h2>

            {error ? (
                <p style={{ color: 'red' }}>Error: {error}</p>
            ) : (
                <table border="1" style={{ width: '100%', textAlign: 'left', borderCollapse: 'collapse' }}>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>CurrencyTypeID</th>
                            <th>Value</th>
                            <th>Description</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        {amountCalculationType.map((item) => (
                            <tr key={item.ID}>
                                <td>{item.ID}</td>
                                <td>{item.Name}</td>
                                <td>{item.CurrencyTypeID}</td>
                                <td>{item.Value}</td>
                                <td>{item.Description}</td>
                                <td>{item.Status}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            )}

            {/* {showForm && (
                <div style={{ marginTop: '20px', border: '1px solid black', padding: '10px' }}>
                    {showForm === 'add' && (
                        <div>
                            <h3>Add New Entry</h3>
                            <input name="name" placeholder="Name" value={formData.name} onChange={handleInputChange} />
                            <input name="currencyTypeId" placeholder="Currency Type ID" value={formData.amountCalculationTypeId} onChange={handleInputChange} />
                            <input name="value" placeholder="Value" value={formData.amount} onChange={handleInputChange} />
                            <input name="description" placeholder="Description" value={formData.description} onChange={handleInputChange} />
                            <input name="status" placeholder="Status" value={formData.status} onChange={handleInputChange} />
                            <button onClick={submitAdd}>Confirm</button>
                            <button onClick={handleCancel}>Cancel</button>
                        </div>
                    )}
                    {showForm === 'remove' && (
                        <div>
                            <h3>Remove Entry</h3>
                            <input name="id" placeholder="ID to Remove" value={formData.id} onChange={handleInputChange} />
                            <button onClick={submitRemove}>Confirm</button>
                            <button onClick={handleCancel}>Cancel</button>
                        </div>
                    )}
                    {showForm === 'modify' && (
                        <div>
                            <h3>Modify Entry</h3>
                            <input name="id" placeholder="ID to Modify" value={formData.id} onChange={handleInputChange} />
                            <button onClick={submitModify}>Confirm</button>
                            <button onClick={handleCancel}>Cancel</button>
                        </div>
                    )}
                    {showForm === 'edit' && (
                        <div>
                            <h3>Edit Entry</h3>
                            <input name="name" placeholder="Name" value={formData.name} onChange={handleInputChange} />
                            <input name="amountCalculationTypeId" placeholder="Amount Calculation Type ID" value={formData.amountCalculationTypeId} onChange={handleInputChange} />
                            <input name="amount" placeholder="Amount" value={formData.amount} onChange={handleInputChange} />
                            <input name="description" placeholder="Description" value={formData.description} onChange={handleInputChange} />
                            <input name="status" placeholder="Status" value={formData.status} onChange={handleInputChange} />
                            <button onClick={submitEdit}>Confirm</button>
                            <button onClick={handleCancel}>Cancel</button>
                        </div>
                    )}
                </div>
            )} */}

        </div>
    
    )

}

export default RetrieveAmountCalculationType;