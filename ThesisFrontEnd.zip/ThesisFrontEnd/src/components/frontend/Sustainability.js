function Sustainability() {

    return (
        <section id="sustainability" className="content-section">
                <h1>Sustainability</h1>
            <p>Our commitment to sustainability includes eco-friendly practices and community engagement.</p>
            </section>
    );
}

export default Sustainability;