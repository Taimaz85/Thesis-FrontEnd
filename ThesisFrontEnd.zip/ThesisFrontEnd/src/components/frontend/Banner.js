function Banner() {

    return (
        <section className="banner">
            <h1>Quality and Tradition in Every Bite</h1>
            <a href="#products" className="cta">Explore Products</a>
            
        </section>
    )
}

export default Banner;