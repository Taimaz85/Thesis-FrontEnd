import '../../styles/product.css'
import productCategoryList from '../product/ProductCategoryList';
import ProductCategoryMap from '../product/ProductCategoryMap';

function Products() {

    return (
        <section id="products" className="content-section">
            {/* <h1>Products</h1>
            <div className="product-category">
                <img className="product-picture" src="./Images/sausage.jpg"
                alt="Picture of susage" />
                <a href="./pages/sausage.html#sausage">
                    <h3>Sausage</h3>
                </a>
                <p>Flavorful sausages made from the finest ingredients.</p>
            </div> */}
            <ProductCategoryMap data = {productCategoryList}/>
            {/* <div className="product-category">
                <img className="product-picture" src="./Images/bacon.jpg"
                alt="Picture of bacon"/>
                <a href="./pages/bacon.html#bacon">
                    <h3>Bacon</h3>
                </a>
                <p>Crispy and savory bacon perfect for any meal.</p>
            </div>
            <div className="product-category">
                <img className="product-picture" src="./Images/ham.jpg"
                alt="Picture of ham"/>
                <a href="./pages/ham.html#ham">
                    <h3>Ham</h3>
                </a>
                <p>Premium ham that melts in your mouth.</p>
            </div>
            <div className="product-category">
                <img className="product-picture" src="./Images/salami.jpg"
                alt="Picture of salami"/>
                <a href="./pages/salami.html">
                    <h3>Salami</h3>
                </a>
                <p>A variety of salamies for pizza and more.</p>
            </div>
            <div className="product-category">
                <img className="product-picture" src="./Images/processed-meat.jpg"
                alt="Picture of processed meats"/>
                <a href="./pages/processedMeat.html">
                    <h3>Processed Meat</h3>
                </a>
                <p>Different taste experience of meats in various products</p>
            </div> */}
        </section>
    );
}

export default Products;