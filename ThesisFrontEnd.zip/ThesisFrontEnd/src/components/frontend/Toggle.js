import Header from "./Header";

function Toggle() {

// Toggle configuration
document.getElementById('mobile-menu').addEventListener('click', function() {
    var navLinks = document.querySelector('nav ul');
    navLinks.classList.toggle('showing');

    // Toggle the cross icon
    this.classList.toggle('toggle');
});
}

