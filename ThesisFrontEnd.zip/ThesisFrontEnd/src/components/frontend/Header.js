import React, { useState } from "react";
import '../../styles/toggle.css';

function Header() {
    const [menuOpen, setMenuOpen] = useState(false);

    // Toggle menu handler
    const handleToggle = () => {
        setMenuOpen(!menuOpen);
    };

    return (
        <header>
            <div className="logo tooltip" data-text="HOME PAGE">
                <a href="../index.html">
                    Processed Meat Products
                </a>
            </div>
            <div className="search">
                <input type="text" placeholder="Search..." id="search-input"/>
                <div id="search-results"></div>
                {/*<script src="./js/search.js"></script>*/}
            </div>
            <nav>
                <ul className={`nav-links ${menuOpen ? 'showing' : ''}`}>
                    <li><a href="#about">About Us</a></li>
                    <li><a href="#products">Products</a></li>
                    <li><a href="#quality">Quality</a></li>
                    <li><a href="#sustainability">Sustainability</a></li>
                    <li><a href="#contact">Contact</a></li>
                    <li><a href="/pages/login.html">Login</a></li>
                </ul>
            </nav>
            <div className="language-selector">
                <a href="#">EN</a> | <a href="#">HU</a>
            </div>

            {/* Mobile menu toggle button */}
            <div 
                className={`menu-toggle ${menuOpen ? 'toggle' : ''}`}
                id="mobile-menu" 
                onClick={handleToggle}
            >
                <span className="bar"></span>
                <span className="bar"></span>
                <span className="bar"></span>
            </div>
            <div 
                onClick={handleToggle}
            ></div>
        </header>
    );
}

export default Header;