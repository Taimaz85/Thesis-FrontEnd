function ContactSection() {

    return (
        <section id="contact" class="content-section">
            <h1>Contact us</h1>
            <form class="contact">
                <label for="name">Name:</label>
                <br></br>
                <input type="text" id="name" name="name"/>
                <br></br>
                <label for="email">Email:</label>
                <br></br>
                <input type="email" id="email" name="email"/>
                <br></br>
                <label for="message">Message:</label>
                <br></br>
                <textarea id="message" name="message"></textarea>
                <br></br>
                <button type="submit">Submit</button>
            </form>

            <hr></hr>

            <div class="contact-info">
                <p>Address: 123 Meat St, Food City</p>
                <p>Phone: (123) 456-7890</p>
                <p>Email: info@meatproducts.com</p>
                <div class="social-media">
                    <a href="#">Facebook</a> | <a href="#">Twitter</a> | <a href="#">Instagram</a>
                </div>
            </div>
        </section>
    );
}

export default ContactSection;