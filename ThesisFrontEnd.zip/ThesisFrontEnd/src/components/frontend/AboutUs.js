function AboutUs() {

    return (
        <section id="about" className="content-section">
            <h1>About Us</h1>
            <p>Our company has a long history of producing high-quality 
                processed meat products. Learn about our journey and values.</p>
        </section>
    );
}

export default AboutUs;