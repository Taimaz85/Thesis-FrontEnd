function Quality() {

    return (
        <section id="quality" className="content-section">
            <h1>Quality</h1>
            <p>We add here to the highest standards of quality control to ensure the best products for our customers.</p>
        </section>
    );
}

export default Quality;