function Footer() {

    return (
        <footer>
            <p>&copy; 2024 Processed Meat Products | BitNJoy Company. All rights reserved.</p>
        </footer>
    )
}

export default Footer;